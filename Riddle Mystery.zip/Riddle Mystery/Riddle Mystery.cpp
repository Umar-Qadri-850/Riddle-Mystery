#include <iostream>

using namespace std;
void riddle();
void ca1();
void ca2();
void ca3();
void ca4();
void ca5();
void ca6();
void ca7();
void ca8();
void ca9();
void ca10();
void ca11();
void ca12();
void wca();
int endgame();
int ropt();
int ropt2();
int ropt3();

int L=0,lose=0,i=0;//L for lose,i for end loop

int main()
{
    cout<<"\n\n\t\t\t A Farmer has a Lion, a Sheep and some Grass. He wants to cross the river,\n\t\t\t  he must use a small boat only big enough for him and one other item.\n\t\t\t\t\tExplain how the Farmer can cross the river.\n";

   do{
    riddle();
    for(int l1=0;l1!=101;l1){
    cout<<"\n\t\t\t\t   choose a item to transport across the river:";
    string ans;
    cin>>ans;
    if (ans=="LION"||ans=="Lion"||ans=="lion"){
    ca1();
    L=1;
    break;
    }
    else if (ans=="GRASS"||ans=="grass"||ans=="Grass"){
        ca2();
        L=1;
        break;
    }
    else if(ans=="SHEEP"||ans=="sheep"||ans=="Sheep"){
        ca3();
        for(int l2=0;l2!=101;l2){//second loop
            if(l2==0){cout<<"\n\t\t\t\t   choose a item to transport across the river:";//1
            string ans;
            cin>>ans;
            if(ans=="GRASS"||ans=="grass"||ans=="Grass"){//2
                ca5();
                lose=ropt();
                if(lose==200){//sheep eat grass//3
                    L=1;
                    l2=101;
                    l1=101;
                    break;
                }//sheep eat grass//3
                else if(lose==300){//4
                    ca3();
                }//4
                else if(400){//5
                ca7();
                l2=2;
            }//6
        }//5
                else if(ans=="LION"||ans=="Lion"||ans=="lion"){
            ca10();
            lose=ropt3();
            if(lose==200){//sheep eat grass//3
                    L=1;
                    l2=101;
                    l1=101;
                    break;
                }
            else if(lose==300){//lion loop
                ca3();
            }
            else if(lose==400){
                l2=3;
            }
    }
    else if(lose=3&&(ans=="SHEEP"||ans=="sheep"||ans=="Sheep")){
            wca();
            cout<<"\n\t\t\t\t   Congratulation you solved the riddle!";
            i=101;
            l2=101;
            l1=101;
            break;
    }
    else{cout<<"\n\t\t\t\t\t\tInvalid Input";}




            }//2
        else if(l2==2){//45
            cout<<"\n\t\t\t\t   choose a item to transport across the river11111:";//1
            string ans;
            cin>>ans;
        if(ans=="SHEEP"||ans=="sheep"||ans=="Sheep"){
                ca5();
                lose=ropt();
                if(lose==200){//sheep eat grass//3
                    L=1;
                    l2=101;
                    l1=101;
                    break;
                }//sheep eat grass//3
                else if(lose==300){//4
                    ca3();
        l2=0;
                }//4
                else if(400){//5
                ca7();
                l2=2;
                lose=3;

                    }
}
if(ans=="LION"||ans=="Lion"||ans=="lion"){
    ca8();

   // i=ropt2();
 //   if(i==200){
            for(int sml=0;sml!=101;sml){
        cout<<"\n\t\t\t\t   choose a item to transport across the river:";//1
        string ans;
        cin>>ans;
        if(ans=="SHEEP"||ans=="sheep"||ans=="Sheep"){
            wca();
            cout<<"\n\t\t\t\t   Congratulation you solved the riddle!";
            i=101;
            l2=101;
            l1=101;
            break;

        }
        else{
            cout<<"\n\t\t\t\t\t\tInvalid Input";
        }
  }
//}
//else if(i==300){
//    ca7();
//}
//else if(i==400||l2==3){
//    if(l2==2){
  //          ca9();
   // }
   // else if(l2==3){
   // cout<<"\n\t\t\t\t   choose a item to transport across the river22222:";
   // }
//}
}
        }//45
        //}//1
            /*else if(l2==1){//*
                ca5();
                lose=ropt();
                if(lose==200){//sheep eat grass
                    L=1;
                    l2=101;
                    l1=101;
                    break;
                }//sheep eat grass
                else if(lose==300){
                    ca3();
                }
                else if(400){
                ca7();
                cout<<"\n\t\t\t\t   choose a item to transport across the river:";
                string ans;
                cin>>ans;
                    if(ans=="SHEEP"||ans=="sheep"||ans=="Sheep"){
                        ans="GRASS";
                        l2=1;
            }

        }
    }//grass 2 choice//*/
//l2==3///////////////////
else if(l2==3){
            ca9();
            for(int i=0;i!=101;i){
            cout<<"\n\t\t\t\t   choose a item to transport across the river12121:";//1
            string ans;
            cin>>ans;
            if(ans=="SHEEP"||ans=="sheep"||ans=="Sheep"){
             ca10();
             l2=4;
             i=101;
            }
            else if(ans=="GRASS"||ans=="grass"||ans=="Grass"){
            ca12();
            ans="lion";
            l2=0;
            i=101;
            }
        }
}
else if(l2==4){
    lose=ropt3();
    if(lose==200){//sheep eat grass//3
        L=1;
        l2=101;
        l1=101;
        break;
    }
    else if(lose==400){
        l2=3;
    }
    else if(lose==300){

        l2=0;
    }
}
            else{
                cout<<"\n\t\t\t\t\t\tInvalid Input";
            }
       } //second loop
    }//first sheep else if
    else{
        cout<<"\n\t\t\t\t\t\tInvalid Input";
    }
    }//first loop
    if(L==1){//for losing
    i=endgame();
    }//for losing
   }while(i!=101);
    return 0;
}

int endgame(){
    string op;
    cout<<"\n\n\t\t\t\t\t   Do you want to play again(Y/N):";
    cin>>op;
    int k;
    for(int j=1;j<=2;j+=0)
    if (op=="n"||op=="N"){
        cout<<"\n\t\t\t\t\t\tYou exited the game";
        return 101;
        break;
    }
    else if (op=="y"||op=="Y"){
        return k=1;
        break;
    }
    else{
        cout<<"\n\t\t\t\t\t\tInvalid Input\n\n\t\t\t\t\t   Do you want to play again(Y/N):";
        cin>>op;
     }
    }
void riddle(){
    cout<<"\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tLION"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tSHEEP"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tGRASS"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;

}
void ca1(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\tSHEEP"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  X"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\tGRASS"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\n\t\t\t\t\t   The sheep will eat the Grass";
}
void ca2(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tLION"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  X"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tSHEEP"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\n\t\t\t\t\t   The LION will eat the SHEEP";
}
void ca3(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tLION"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tGRASS  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca4(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tGRASS  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca5(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tLION"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca6(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tLION"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\tX\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca7(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tLION"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tSHEEP"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca8(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tSHEEP"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void wca(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca9(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tSHEEP"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tGRASS  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca10(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tGRASS  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca11(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\tX\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\tSHEEP\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tGRASS  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}
void ca12(){
    cout<<"\n\n\n\n\n\n\n\n\n\n\n\t\tLEFT SIDE\t|\t\t\tRIVER\t\t\t|\tRIGHT SIDE"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tLION\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t  "<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\tSHEEP"<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\tGRASS\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t  "<<endl;
    cout<<"\t\t\t\t|\t~\t~\t~\t~\t~      ~|\t"<<endl;
    cout<<"\t\t\t\t|~\t\b~\t\b~\t\b~\t\b~\t\b~      \b~  |\t"<<endl;
}

int ropt(){
     string op;
    cout<<"\n\n\t\t\t\t\t   Do you want to bring the back anything(Y/N):";
    cin>>op;
        for(int j=1;j<=200;j+=0){
    if (op=="n"||op=="N"){
        ca6();
        cout<<"\n\t\t\t\t\t\tYou have Returned to the Right Side"<<endl;
        cout<<"\n\t\t\t\t\t\tThe SHEEP will Eat the GRASS";
        L=1;
        return 200;
        break;
    }
    else if (op=="y"||op=="Y"){
            cout<<"\n\t\t\t\t\t\tWhat do you want to bring to the Right Side:";
            cin>>op;
            if(op=="GRASS"||op=="grass"||op=="Grass"){
                cout<<"\n\t\t\t\t\t\t The GRASS is on the right side";
                return 300;
            }
            else if(op=="SHEEP" || op=="sheep" || op=="Sheep"){
               cout<<"\n\t\t\t\t\t\t The sheep is on the right side";
               return 400;
            }
        break;
    }
    else{
        cout<<"\n\t\t\t\t\t\tInvalid Input\n\n\t\t\t\t\t   Do you want to bring the back anything(Y/N):";
        cin>>op;
     }
    }

}
int ropt2(){
     string op;
    cout<<"\n\n\t\t\t\t\t   Do you want to bring the back anything(Y/N):";
    cin>>op;
    for(int i=0;1!=101;i){
        if (op=="n"||op=="N"){
                ca8();
            cout<<"\n\t\t\t\t\t\tYou have Returned to the Right Side";
            return 200;
        }
        else if (op=="y"||op=="Y"){
            cout<<"\n\t\t\t\t\t\tWhat do you want to bring to the Right Side:";
            cin>>op;
        }
        else if(op=="LION"||op=="Lion"||op=="lion"){
            cout<<"\n\t\t\t\t\t\t The LION is on the right side";
            return 300;
        }
        else if(op=="GRASS"||op=="grass"||op=="Grass"){
            cout<<"\n\t\t\t\t\t\t The GRASS is on the right side";
            return 400;
        }
    else{
        cout<<"\n\t\t\t\t\t\tInvalid Input\n\n\t\t\t\t\t   Do you want to bring the back anything(Y/N):";
        cin>>op;
    }
    }
}
int ropt3(){
     string op;
    cout<<"\n\n\t\t\t\t\t   Do you want to bring the back anything(Y/N):";
    cin>>op;
  for(int j=1;j<=200;j+=0){
  if (op=="n"||op=="N"){
        ca11();
        cout<<"\n\t\t\t\t\t\tYou have Returned to the Right Side"<<endl;
        cout<<"\n\t\t\t\t\t\tThe LION will Eat the SHEEP";
        L=1;
        return 200;
        break;
    }
    else if(op=="y"||op=="Y"){
        for(int i=0;i=101;i){
            cout<<"\n\t\t\t\t\t\tWhat do you want to bring to the Right Side:";
            cin>>op;
            if(op=="LION"||op=="Lion"||op=="lion"){
            cout<<"\n\t\t\t\t\t\t The LION is on the right side";
            return 300;
            }
            else if(op=="SHEEP"||op=="Sheep"||op=="sheep"){
            cout<<"\n\t\t\t\t\t\t The SHEEP is on the right side";
            return 400;
            }
        }
    }
  }
}

